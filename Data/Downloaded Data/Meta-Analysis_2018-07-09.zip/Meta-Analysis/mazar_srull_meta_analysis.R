suppressPackageStartupMessages({
  library(metafor)
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(stringr)
  library(gridExtra)
  library(Cairo)
  library(stargazer)
  library(readxl)
  library(openxlsx)})

sink('Results/session_info.txt')
sessionInfo()
sink()

#Get the standard error of the difference between two sets of data
sediff <- function(x, y) sqrt((var(x)/length(x))
                              + (var(y)/length(y)))

bias_round <- function(x, n) {
  posneg <- sign(x)
  z <- trunc((abs(x)*10^n) + .5)/(10^n)
  z*posneg
}

#Extract raw difference of means and SE of means for an arbitrary condition.
#If variances are supplied, treat as difference-of-differences.
get_effect <- function(data, g1_cond, g2_cond, label, 
                       g1_var=NULL, g2_var=NULL, variances=NULL, n=NULL) {
  if (!is.null(variances)) {
    g1_mean <- g1_cond
    g2_mean <- g2_cond
    diff <- g1_mean - g2_mean
    se <- sqrt(variances[1] + variances[2])
    n1 <- n[1]
    n2 <- n[2]
  } else {
    g1_var <- enquo(g1_var)
    g1_cond <- enquo(g1_cond)
    g2_var <- enquo(g2_var)
    g2_cond <- enquo(g2_cond)
    g1 <- filter(data, !!g1_cond) %>%
          select(!!g1_var) %>%
          filter(!is.na(!!g1_var))
    g1_mean <- summarize(g1, m = mean(!!g1_var))$m
    g2 <- filter(data, !!g2_cond) %>%
          select(!!g2_var) %>%
          filter(!is.na(!!g2_var))
    g2_mean <- summarize(g2, m = mean(!!g2_var))$m
    diff <- g1_mean - g2_mean
    se <- sediff(g1[[1]], g2[[1]])
    n1 <- nrow(g1)
    n2 <- nrow(g2)
  }
  data_frame('label'=label,
             'effect'=diff, 
             'se'=se,
             'g1_mean'=g1_mean,
             'g2_mean'=g2_mean,
             'n1'=n1,
             'n2'=n2)
}

#This function collapses a lab's individual subject data into one data frame, then
#extracts and saves the meta-analytic effects.
#After data is bound together, process subject-level effects.
#At this stage, also label each lab's meta-analytic effects with necessary markers
#to perform lab-level exclusions.
process_raw <- function(file) {
  params <- strsplit(file, split='[/_]')
  lab <- params[[1]][2]
  print(lab)
  dat <- read_excel(file, sheet='data') %>% 
         mutate_at(vars(num.boxes, num.boxes.correct, religious1:religious3), funs(as.numeric)) %>%
         mutate_at(.vars=vars(religious1:religious3), .funs=funs(ifelse(. < 1 | . > 5, NA, .))) %>%
         mutate(num.boxes = ifelse(num.boxes < 0 | num.boxes > 20, NA, num.boxes)) %>%
         filter((inclusion == "inclusion both RRR" | inclusion == "inclusion Mazar only") &
                   !is.na(maz.cheat.cond) &
                   !is.na(maz.prime.cond) &
                   !is.na(num.boxes) &
                  round(num.boxes) == num.boxes)
  cheat <- filter(dat, maz.cheat.cond=='cheat')
  nocheat <- filter(dat, maz.cheat.cond=='no cheat')
  books <- filter(dat, maz.prime.cond=='books')
  commands <- filter(dat, maz.prime.cond=='commandments')
  cvb <- group_by(dat, maz.prime.cond) %>%
    summarize(diff=mean(num.boxes[maz.cheat.cond=='cheat']) - mean(num.boxes[maz.cheat.cond=='no cheat']),
              vardiff=sediff(num.boxes[maz.cheat.cond=='cheat'], num.boxes[maz.cheat.cond=='no cheat'])**2,
              n=n()) %>%
    gather(stat, value, diff, vardiff, n) %>%
    spread(maz.prime.cond, value)
  cvb_permaa <- group_by(dat, maz.prime.cond) %>%
    summarize(diff=mean(num.boxes[maz.cheat.cond=='cheat']) - mean(num.boxes.correct[maz.cheat.cond=='no cheat'], na.rm=TRUE),
              vardiff=sediff(num.boxes[maz.cheat.cond=='cheat'], num.boxes.correct[maz.cheat.cond=='no cheat'])**2,
              n=n()) %>%
    gather(stat, value, diff, vardiff, n) %>%
    spread(maz.prime.cond, value)
  
  cheat_eff <- get_effect(cheat, g1_cond = maz.prime.cond=='commandments', 
                          g2_cond = maz.prime.cond=='books', label='10 commandments effect',
                          g1_var = num.boxes, g2_var = num.boxes)
  nocheat_eff <- get_effect(nocheat, g1_cond = maz.prime.cond=='commandments',
                            g2_cond = maz.prime.cond=='books', label = 'control condition',
                            g1_var = num.boxes, g2_var = num.boxes)
  nocheat_eff_permaa <- get_effect(filter(nocheat, !is.na(num.boxes.correct)), 
                            g1_cond = maz.prime.cond=='commandments',
                            g2_cond = maz.prime.cond=='books', label = 'control condition permaa',
                            g1_var = num.boxes.correct, g2_var = num.boxes.correct)
  books_eff <- get_effect(books, g1_cond = maz.cheat.cond=='cheat',
                          g2_cond = maz.cheat.cond=='no cheat', label = 'cheating',
                          g1_var = num.boxes, g2_var = num.boxes)
  books_eff_permaa <- get_effect(books, g1_cond = maz.cheat.cond=='cheat',
                          g2_cond = maz.cheat.cond=='no cheat' & !is.na(num.boxes.correct),
                          label = 'cheating permaa',
                          g1_var = num.boxes, g2_var = num.boxes.correct)
  commands_eff <- get_effect(commands, g1_cond = maz.cheat.cond=='cheat',
                            g2_cond = maz.cheat.cond=='no cheat', label = 'commandments condition',
                            g1_var = num.boxes, g2_var = num.boxes)
  commands_eff_permaa <- get_effect(commands, g1_cond = maz.cheat.cond=='cheat',
                             g2_cond = maz.cheat.cond=='no cheat' & !is.na(num.boxes.correct), 
                             label = 'commandments condition permaa',
                             g1_var = num.boxes, g2_var = num.boxes.correct)
  cvb_eff <- get_effect(cvb, g1_cond=unlist(cvb[1, 2]) , g2_cond=unlist(cvb[1, 3]), label='difference',
                        variances=unlist(cvb[3, 2:3]), n=unlist(cvb[2, 2:3]))
  cvb_eff_permaa <- get_effect(cvb_permaa, g1_cond=unlist(cvb_permaa[1, 2]) , 
                               g2_cond=unlist(cvb_permaa[1, 3]), label='difference permaa',
                        variances=unlist(cvb_permaa[3, 2:3]), n=unlist(cvb_permaa[2, 2:3]))
  self_vs_exp <- get_effect(filter(nocheat, !is.na(num.boxes.correct)), 
                            g1_cond=TRUE, g2_cond=TRUE, label = 'self report vs external check',
                            g1_var = num.boxes, g2_var = num.boxes.correct)
  
  #Assemble and save out results file; this file is passed to the meta-analysis script
  meta_effects <- rbind(cheat_eff, nocheat_eff, nocheat_eff_permaa, books_eff, books_eff_permaa,
                        commands_eff, commands_eff_permaa, cvb_eff, cvb_eff_permaa, self_vs_exp)
  meta_effects$language <- dat$language[1]
  meta_effects$male_prop <- sum(dat$gender == 'male')/nrow(dat)
  meta_effects$total_n <- nrow(dat)
  meta_effects[,paste0('religious', 1:3, '_mean')] <- select(dat, paste0('religious', 1:3)) %>%
                                                 mutate_all(as.numeric) %>%
                                                 summarize_all(mean, na.rm=TRUE)
  meta_effects$religious_grandmean <- rowMeans(meta_effects[, paste0('religious', 1:3, '_mean')])
  write.csv(meta_effects, paste('Data/', lab, '_data_meta.csv', sep=''), row.names=FALSE)
}

#If the data have not been processed to extract just the information needed for the
#meta-analysis, do so.

all_files <- list.files(path='Data', pattern="*.xlsx", full.names=TRUE)

if (length(list.files(path='Data', pattern="*_data_meta.csv")) < length(list.files(path='Data', pattern="*.xlsx"))) {
  names(all_files) <- sapply(strsplit(all_files, split='[_/]'), function(x){x[2]})
  lapply(all_files, process_raw)
}

all_raw <- all_files %>%
  map(read_excel, sheet='data', col_types='text') %>%
  map_df(bind_rows) %>%
  mutate_at(.vars=vars(starts_with('ron'), starts_with('hex'), starts_with('religious'),
                      starts_with('fatigue'), starts_with('behavior'), starts_with('raven'),
                      contains('num'), contains('hours'), contains('minutes'), contains('seconds'),
                      contains('paperclip'), id, age),
           .funs=funs(as.numeric)) %>%
  mutate_if(is.character, funs(ifelse(!is.na(.), str_replace_all(., '\n?\r?', ''), .))) %>%
  rename_all(str_replace, pattern='raven', replacement='matrix') %>%
  mutate_at(.vars=vars(starts_with('matrix')), .funs=funs(ifelse(. < 1 | . > 8, NA, .))) %>%
  mutate_at(.vars=vars(religious1:religious3, fatigue1:fatigue6, hex1:hex60),
            .funs=funs(ifelse(. < 1 | . > 5, NA, .))) %>%
  mutate_at(.vars=vars(ron.hostile:ron.interesting, behavior1:behavior6, judgedcreativity.paperclips),
            .funs=funs(ifelse(. < 0 | . > 10, NA, .))) %>%
  mutate(num.boxes=ifelse(round(num.boxes) != num.boxes, NA, num.boxes)) %>%
  mutate(date.tested = ifelse(!is.na(as.Date(as.numeric(date.tested), origin = "1899-12-30")),
                as.character(as.Date(as.numeric(date.tested), origin = "1899-12-30")),
                date.tested),
         language=str_to_title(language),
         compensation=ifelse(str_detect(str_to_lower(compensation), 'course|class|credit'),
                             'course credit', compensation),
         kept.sheet=str_to_upper(kept.sheet),
         inclusion = ifelse(is.na(maz.prime.cond) | is.na(maz.cheat.cond) | is.na(num.boxes),
                            'exclusion', inclusion),
         lab.name = case_when(
           lab.name == 'Blatz_Crusius' ~ 'Blatz',
           lab.name == 'LoschelderMechtel' ~ 'Loschelder',
           lab.name == 'McCarthy' ~ 'McCarthy',
           lab.name == 'Voracek' ~ 'Tran',
           lab.name == 'Nahari' | lab.name == 'klein Selle' ~ 'klein Selle & Rozmann',
           TRUE ~ str_to_title(lab.name))) %>%
  filter(!(lab.name %in% c('Huntjens', 'Sumapouw', 'Willis')) & !(is.na(lab.name))) %>%
  select(1:144)

write.csv(all_raw, 'Results/raw_data_corrected_MAA.csv')
write.xlsx(all_raw, 'Results/raw_data_corrected_MAA.xlsx', colNames=TRUE)

#Load in and bind all the meta-analytic effects, labeled with the lab to which the
#data belong.
all_files <- list.files(path='Data', pattern="*_data_meta.csv", full.names=TRUE)
authors <- sapply(strsplit(all_files, split='[_/]'), function(x){x[2]})
names(all_files) <- authors
all_dat <- map(all_files, read.csv) %>% 
           map_df(bind_rows, .id='authors')

#This function takes in the meta-analytic information for one effect, runs a random effects
#model, and outputs the data in an easily plottable format.
clean_model <- function(data, effect_label=data$label[1], subgroup=TRUE, summary_label, path) {
  rma.mod <- rma(yi=effect, sei=se, slab=authors, data=data, method='REML')
  if (length(unique(data$authors)) > 1) {
    sink(file=paste0(path, 'Model Output/', effect_label, '.txt'))
    print(rma.mod, digits=16)
    sink()
  }
  
  output <- data.frame('means'=c(rma.mod$yi, rma.mod$b),
                       'se'=c(sqrt(rma.mod$vi), rma.mod$se),
                       'ci_l'=c(rma.mod$yi - qnorm(.025, lower.tail=F)*data$se, rma.mod$ci.lb),
                       'ci_u'=c(rma.mod$yi + qnorm(.025, lower.tail=F)*data$se, rma.mod$ci.ub),
                       'authors'=as.character(c(rma.mod$slab, 
                                                paste(summary_label, 
                                                      collapse=as.character(effect_label)))),
                       'class'=as.character(c(as.character(data$label), 'summary')),
                       'class_n'= c(rep(1, length(rma.mod$slab)), 0),
                       'n1'=c(data$n1, sum(data$n1)),
                       'n2'=c(data$n2, sum(data$n2)),
                       'mean1' = c(data$g1_mean, mean(data$g1_mean)),
                       'mean2' = c(data$g2_mean, mean(data$g2_mean)),
                       'group_priority'=c(rep(2, length(rma.mod$slab)), 3),
                       'shape'=c(rep(15, length(rma.mod$slab)), 18))
  if (subgroup) {
    output <- full_join(output, 
                        data.frame('authors'=effect_label, 
                                   'class'=effect_label, 
                                   'class_n'=1,
                                   'group_priority'=1))
  }
  return(output)
}

#A helper function to run models for multiple effects at once.
construct_models <- function(data, subgroup=TRUE, summary_label=c('Meta-analytic average for \n', ''), path) {
  sapply(unique(data$label),
                   function(lab) clean_model(data[data$label==lab,], lab, subgroup, summary_label, path),
         simplify=FALSE) %>% map_df(bind_rows)
}

#A function that takes in the results from the model-generating functions and creates a forest plot.
plot_meta <- function(results, width, height, ilab='Lab', save=FALSE, filename='', path,
                      summary_only=FALSE, auth_width, title, g1_label, g2_label) {
  meta_theme <- theme_bw() +
    theme(rect = element_blank(),
          panel.grid.major=element_blank(),
          panel.grid.minor=element_blank(),
          panel.border=element_blank(),
          axis.ticks.y = element_blank(), 
          panel.spacing = unit(c(0, 0, 0, 0), "npc"),
          plot.margin = unit(c(5, 0, 5, 0), "pt"),
          axis.line.x=element_line(color='black'),
          axis.line.y=element_blank(),
          axis.text.x=element_text(size=10, color='black'),
          axis.text.y=element_blank(),
          legend.position='none',
          plot.title = element_text(hjust = 0.5))
  
  weights <- (1/sqrt(results$se))/sum(1/sqrt(results$se), na.rm=T)
  psize <- ((weights - min(weights, na.rm=T))/(max(weights, na.rm=T) - min(weights, na.rm=T)))
  results$size <- psize #careful that this weighting for the summary stat is appropriate
  
  if (!('Original result' %in% unique(results$authors))) {
    arrby = quo(means)
  } else if (filter(results, authors == 'Original result')$means < 0) {
    arrby = quo(means)
  } else if (filter(results, authors == 'Original result')$means > 0) {
    arrby = quo(desc(means))
  }
  
  results <- arrange(results, desc(class_n), class, group_priority, !! arrby) %>%
               mutate(study_n=1:n())
  
  results$size[results$shape==17] = .3
  if (17 %in% results$shape) {
    shapes <- c(15, 17, 18)
    shift_by <- setNames(1:length(sort(unique(results$class))), sort(unique(results$class)))
    results <- mutate(results, study_n=study_n+shift_by[class]) %>%
               mutate(study_n=ifelse(group_priority %in% c(2, 3), study_n, study_n - 1))
    
    if (length(unique(results$class)) > 2) {
      results <- mutate(results, study_n=ifelse(shift_by[class] > 1, study_n + 1, study_n))
    }
    
    class_lines <- unlist(group_by(results, class) %>% 
                      filter(shape != 17) %>% 
                      summarize(m=min(study_n)) %>% 
                      select(m) - 1)
    if (length(unique(results$class)) > 2) {
      div_coords <- c(class_lines, 0, class_lines[2] - class_lines[1])
    } else {
      div_coords <- c(class_lines, 0)
    }
  
  } else {
    shapes <- c(15, 18)
    results <- mutate(results, study_n=ifelse(class=='summary', study_n+1, study_n))
    div_coords <- c(min(filter(results, class=='summary')$study_n) - 1, 0)
  }
  offset <- .005
  if (summary_only) {
    results <- filter(results, class=='summary') %>%
               mutate(study_n=1:n())
    div_coords <- 0
    offset <- 0
  }
  
  maxval <- max(abs(na.omit(c(results$ci_u, results$ci_l))))
  breakpoint <- case_when(maxval < 5 ~ 5, 
                          maxval > 5 & maxval < 10 ~ 15,
                          maxval > 10 & maxval < 20 ~ 25)
  
  forest <- ggplot(results, aes(y=study_n, x=means)) +
    geom_segment(x=0, xend=0, y=0, yend=-max(results$study_n) - 4, color='gray', linetype='dotted') +
    geom_point(aes(size=size, shape=as.factor(shape))) +
    geom_errorbarh(aes(xmin=ci_l, xmax=ci_u), height=.1) +
    scale_shape_manual(values=shapes) +
    annotate('text', x=0, y=-1, label=title) +
    geom_hline(yintercept=div_coords, lty='dashed') +
    scale_y_reverse(limits=c(max(results$study_n) + 1, -1)) +
    scale_x_continuous(breaks=seq(-breakpoint, breakpoint, ifelse(breakpoint %% 10 == 0, 10, 5)), 
                       limits=c(-breakpoint-3, breakpoint+3)) +
    xlab(NULL) +
    ylab(NULL) +
    meta_theme
  
  text_theme <- theme(panel.grid.major = element_blank(), 
                      legend.position = "none",
                      panel.border = element_blank(),
                      axis.text.y =  element_blank(),
                      axis.ticks =  element_blank(),
                      axis.title.y = element_blank(),
                      plot.title = element_text(hjust = 0.5),
                      axis.line.x=element_line(color='transparent'),
                      axis.text.x=element_text(color='transparent'))
  
  results <- mutate(results, mean_annot=ifelse(!is.na(means), sprintf('% 0.2f', bias_round(means, 2)), NA),
                    ci=ifelse(!is.na(ci_u), sprintf('[% 00.2f, % 00.2f]', round(ci_l, 2), bias_round(ci_u, 2)), NA),
                    m1_annot=ifelse(!is.na(mean1), sprintf('% 0.2f', bias_round(mean1, 2)), NA),
                    m2_annot=ifelse(!is.na(mean2), sprintf('% 0.2f', bias_round(mean2, 2)), NA))
  
  authors <- ggplot(results) +
    annotate('text', x=.015, y=-1, label=ilab) +
    geom_text(aes(x = offset, y=filter(results, group_priority!=1)$study_n, 
                  label=filter(results, group_priority!=1)$authors), hjust=0) +
    geom_hline(yintercept=div_coords, lty='dashed') +
    scale_y_reverse(limits=c(max(results$study_n) + 1, -1)) +
    xlim(0, .05) +
    xlab(NULL) +
    ylab(NULL) +
    meta_theme +
    text_theme
    
  if (min(results$group_priority) == 1) {
    authors <- authors + 
      annotate("text", x=0, y=filter(results, group_priority==1)$study_n, 
               label=toupper(filter(results, group_priority==1)$authors), 
               hjust=0, fontface='bold')
  }
  
  m1 <- ggplot() +
    annotate('text', x=.015, y=-1, label=g1_label) +
    annotate("text", x=.01, y=results$study_n, label=results$m1_annot, hjust=0) +
    geom_hline(yintercept=div_coords, lty='dashed') +
    scale_y_reverse(limits=c(max(results$study_n) + 1, -1)) +
    xlim(0, .05) +
    xlab(NULL) +
    ylab(NULL) +
    meta_theme +
    text_theme
  
  n1 <- ggplot() +
    annotate('text', x=.015, y=-1, label='N') +
    annotate("text", x=0, y=results$study_n, label=results$n1, hjust=0) +
    geom_hline(yintercept=div_coords, lty='dashed') +
    scale_y_reverse(limits=c(max(results$study_n) + 1, -1)) +
    xlim(0, .05) +
    xlab(NULL) +
    ylab(NULL) +
    meta_theme +
    text_theme
  
  m2 <- ggplot() +
    annotate('text', x=.015, y=-1, label=g2_label) +
    annotate("text", x=0.01, y=results$study_n, label=results$m2_annot, hjust=0) +
    geom_hline(yintercept=div_coords, lty='dashed') +
    scale_y_reverse(limits=c(max(results$study_n) + 1, -1)) +
    xlim(0, .05) +
    xlab(NULL) +
    ylab(NULL) +
    meta_theme +
    text_theme
  
  n2 <- ggplot() +
    annotate('text', x=.015, y=-1, label='N') +
    annotate("text", x=0, y=results$study_n, label=results$n2, hjust=0) +
    geom_hline(yintercept=div_coords, lty='dashed') +
    scale_y_reverse(limits=c(max(results$study_n) + 1, -1)) +
    xlim(0, .05) +
    xlab(NULL) +
    ylab(NULL) +
    meta_theme +
    text_theme
  
  effect <- ggplot() +
    annotate('text', x=.015, y=-1, label='ES') +
    annotate("text", x=0, y=results$study_n, label=results$mean_annot, hjust=0) +
    geom_hline(yintercept=div_coords, lty='dashed') +
    scale_y_reverse(limits=c(max(results$study_n) + 1, -1)) +
    xlim(0, .05) +
    xlab(NULL) +
    ylab(NULL) +
    meta_theme +
    text_theme
  
  ci <- ggplot() +
    annotate('text', x=.02, y=-1, label='95% CI') +
    annotate("text", x=0, y=results$study_n, label=results$ci, hjust=0) +
    geom_hline(yintercept=div_coords, lty='dashed') +
    scale_y_reverse(limits=c(max(results$study_n) + 1, -1)) +
    xlim(0, .05) +
    xlab(NULL) +
    ylab(NULL) +
    meta_theme +
    text_theme
  
  widths <- c(auth_width, 1.86, .5, 1.86, .5, 3.75, .75, 1.25)
  metaplot <- grid.arrange(ggplotGrob(authors), ggplotGrob(m1), ggplotGrob(n1),
               ggplotGrob(m2), ggplotGrob(n2), ggplotGrob(forest), 
               ggplotGrob(effect), ggplotGrob(ci), 
               ncol=8, widths=unit(widths, "in"))
  if (save) {
    mapply(function(f, d) ggsave(plot=metaplot, filename=f, units='in', width=sum(widths), 
                                 height=height, device=d, path=paste0(path, 'Plots/')),
           f=paste0(filename, c('.png', '.pdf')), d=c("png", CairoPDF))
  }
}

#Handle the modeling and plotting of a meta-regression.
metaregress <- function(data, effect, moderator, width, height, xlab, save=FALSE, filename='', path) {
  suppressWarnings(rma.mod <- rma(yi=data[[effect]], vi=0, mods = ~ data[[moderator]], slab=data$authors))
  sink(file=paste0(path, 'Model Output/', moderator, '.txt'))
  print(rma.mod, digits=16)
  sink()
  labs <- data.frame('effects'=rma.mod$yi,
                     'mods'=data[[moderator]],
                     'se'=data$se,
                     'authors'=rma.mod$slab)
  weights <- (1/sqrt(labs$se))/sum(1/sqrt(labs$se), na.rm=T)
  psize <- ((weights - min(weights, na.rm=T))/(max(weights, na.rm=T) - min(weights, na.rm=T)))
  labs$size <- psize
  fitted_vals <- cbind(rbind(as.data.frame(predict.rma(rma.mod)), 
                       as.data.frame(predict.rma(rma.mod, c(1, 5)))), 
                       'x'=c(labs$mods, 1, 5))
  
  regtheme <- theme_bw() +
            theme(rect = element_blank(),
                  panel.grid.major=element_blank(),
                  panel.grid.minor=element_blank(),
                  panel.border=element_blank(),
                  axis.ticks.y = element_blank(), 
                  panel.spacing = unit(c(0, 0, 0, 0), "npc"),
                  plot.margin = unit(c(5, 0, 5, 0), "pt"),
                  axis.line.x=element_line(color='black'),
                  axis.text.x=element_text(size=10, color='black'),
                  axis.line.y=element_line(color='black'),
                  axis.text.y=element_text(size=10, color='black'),
                  legend.position='none',
                  plot.title = element_text(hjust = 0.5))
          
  regplot <- ggplot() +
    geom_abline(slope=rma.mod$b[2, 1], intercept=rma.mod$b[1, 1], color='black') +
    geom_line(data=fitted_vals, aes(x=x, y=ci.ub), color='black', lty='dashed') +
    geom_line(data=fitted_vals, aes(x=x, y=ci.lb), color='black', lty='dashed') +
    geom_point(data=labs, aes(x=mods, y=effects, size=size), color='black', fill='gray', shape=21) +
    geom_text_repel(data=labs, aes(x=mods, y=effects, label=authors), force=1.5, point.padding=.15, segment.color=NA) +
    xlab(xlab) +
    ylab('10 Commandment effect (Commandments-Cheat minus Books-Cheat)') +
    ylim(-2, 2) +
    xlim(1, 5) +
    regtheme
  
  if (save) {
    mapply(function(f, d) ggsave(plot=regplot, filename=f, units='in', width=width, 
                                 height=height, device=d, path=paste0(path,'Plots/')),
           f=paste0(filename, c('.png', '.pdf')), d=c("png", CairoPDF))
  }
}

make_output <- function(data, path, original_effects=NULL, eff_labels, plot_params,
                        table_params=NULL, meta_regress=TRUE, save_plots=FALSE, 
                        table_output=FALSE) {
  write.csv(data, file=paste0(path, 'analysis_data.csv'))
  if (is.null(original_effects)) {
    eff.rma <- map(eff_labels, 
                   function(lab) 
                     construct_models(filter(data, label==lab), subgroup=FALSE, path=path) %>%
                             mutate(authors=as.character(authors), class=as.character(class)))
  } else {
    eff.rma <- map(eff_labels, 
                   function(lab) 
                     rbind(construct_models(filter(data, label==lab), subgroup=FALSE, path=path) %>%
                             mutate(authors=as.character(authors), class=as.character(class)),
                           construct_models(filter(original_effects, label==lab), subgroup=FALSE, path=path) %>%
                             mutate(shape=17, group_priority=1.5) %>%
                             filter(class_n==1)))
  }

  #Plot all the forest plots.
  mapply(plot_meta, results=eff.rma, width=plot_params$width, height=plot_params$height,
         ilab=plot_params$ilab, save=save_plots, filename=eff_labels, path=path,
         summary_only=plot_params$summary_only, auth_width=plot_params$auth_width, 
         title=plot_params$title, g1_label=plot_params$g1_lab, g2_label=plot_params$g2_lab)

  if (meta_regress) {
    #Run and plot all the metaregressions.
    mapply(metaregress, data=list(filter(data, label=='10 commandments effect')),
           'effect', c(paste0('religious', 1:3, '_mean'), 'religious_grandmean'),
           xlab = c('Religiousness', 'Belief in God', 'Belief in a Punishing God', 
                     'Average Religiousness Score'),
           width=7, height=7, save=save_plots,
           filename=paste0('metareg_', c('r1', 'r2', 'r3', 'rgm')), path=path)
  }
  #write the data in a form easy to convert to a table.
  if (table_output) {
    make_table <- function(data, title='', path){
      tdata <- arrange(data, desc(class_n), class, group_priority, authors) %>%
        mutate(ci_l=ifelse(!is.na(ci_l), sprintf('% 00.2f', ci_l), NA),
               ci_u=ifelse(!is.na(ci_u), sprintf('% 00.2f', ci_u), NA),
               means=ifelse(!is.na(means), sprintf('% 0.2f', means), NA),
               mean1=ifelse(!is.na(mean1), sprintf('% 0.2f', mean1), NA),
               mean2=ifelse(!is.na(mean2), sprintf('% 0.2f', mean2), NA),
               se=ifelse(!is.na(se), sprintf('% 0.2f', se), NA)) %>%
        select(-shape)
      tdata <- tdata[,c('authors', 'mean1', 'n1', 'mean2', 'n2', 'means', 'se', 
                        'ci_l', 'ci_u', 'class', 'class_n', 'group_priority')]
      
      tlabs <- filter(table_params, class==unique(data$class)[unique(data$class) != 'summary'])
      colnames(tdata)[1:9] <- c('Lab', paste(tlabs$g1, 'Mean'), paste(tlabs$g1, 'N'), 
                                paste(tlabs$g2, 'Mean'), paste(tlabs$g2, 'N'), 'ES', 'SE', 'CI (LB)', 'CI (UB)')
      stargazer(tdata[,1:9], summary=FALSE, rownames=FALSE, title = tlabs$title,
                out=paste0(path, 'Tables/Raw/', unique(data$class)[unique(data$class) != 'summary'], '_table.tex'))
    }
    
    mapply(function(file, filename, path) write.csv(arrange(file, desc(class_n), class, group_priority, authors), 
                                    paste0(path, 'Tables/Raw/', filename,'_table_data.csv', collapse='_'), row.names=FALSE),
           file=eff.rma, filename=eff_labels, path=path)
    
    table_files <- lapply(list.files(path=paste0(path, 'Tables/Raw/'), pattern="*_table_data.csv", full.names=TRUE), read.csv, stringsAsFactors=FALSE)
    
    mapply(make_table, data=table_files, title=eff_labels, path=path)
  }
}

#Process the original effects into the meta-analysis format where possible
#NB external check = no cheating, self check = cheating
original_data <- read_excel('Exp1_BooksCommandments.xls')
colnames(original_data) <- c('prime_cond', 'items_rec', 'cheat', 'num.boxes')
cvb <- group_by(original_data, prime_cond) %>%
  summarize(diff=mean(num.boxes[cheat=='Self']) - mean(num.boxes[cheat=='External']),
            vardiff=sediff(num.boxes[cheat=='Self'], num.boxes[cheat=='External'])**2,
            n=n()) %>%
  gather(stat, value, diff, vardiff, n) %>%
  spread(prime_cond, value)

original_effects <- rbind(get_effect(filter(original_data, cheat=='Self'), 
                                     g1_cond = prime_cond=='Commandments',
                                     g2_cond = prime_cond=='Books', label = '10 commandments effect',
                                     g1_var = num.boxes, g2_var = num.boxes),
                          get_effect(filter(original_data, prime_cond=='Commandments'), 
                                     g1_cond = cheat == 'Self',
                                     g2_cond = cheat == 'External', label = 'commandments condition',
                                     g1_var = num.boxes, g2_var = num.boxes),
                          get_effect(filter(original_data, cheat=='External'), 
                                     g1_cond = prime_cond=='Commandments',
                                     g2_cond = prime_cond=='Books', label = 'control condition',
                                     g1_var = num.boxes, g2_var = num.boxes),
                          get_effect(filter(original_data, prime_cond=='Books'),
                                     g1_cond = cheat == 'Self',
                                     g2_cond = cheat == 'External', label = 'cheating',
                                     g1_var = num.boxes, g2_var = num.boxes),
                          get_effect(cvb, unlist(cvb[1, 2]) , unlist(cvb[1, 3]), 'difference',
                                     var=unlist(cvb[3, 2:3]), n=unlist(cvb[2, 2:3])))
original_effects$authors <- 'Original result'

always_exclude <- c('Huntjens', 'Sumampouw', 'Willis')
all_dat <- mutate(all_dat, label=as.character(label)) %>%
          mutate(authors = ifelse(str_detect(authors, 'zdo'), '\u00D6zdo\u011Fru', authors))

main <- filter(all_dat, total_n >= 200 &
                 !(authors %in% always_exclude))

strict <- filter(all_dat, male_prop >= .2 &
                   1 - male_prop >= .2 & 
                   total_n >= 200 & 
                   !(authors %in% c('Aczel', 'Holzmeister', 'Koppel', 'Loschelder')))

all <- filter(all_dat, !(authors %in% always_exclude))

all_dat_permaa <- filter(all_dat, label %in% c('cheating permaa', 'commandments condition permaa', 
                                               '10 commandments effect', 'control condition permaa', 'difference permaa')) %>%
                  mutate(old_lab = label, label = str_replace_all(label, ' permaa', ''))

main_permaa <- filter(all_dat_permaa, total_n >= 200 &
                 !(authors %in% always_exclude))

strict_permaa <- filter(all_dat_permaa, male_prop >= .2 &
                   1 - male_prop >= .2 & 
                   total_n >= 200 & 
                   !(authors %in% c('Aczel', 'Holzmeister', 'Koppel', 'Loschelder')))

all_permaa <- filter(all_dat_permaa, !(authors %in% always_exclude))

analyses <- list(main, strict, all, main_permaa, strict_permaa, all_permaa)
paths <- c('Results/Main/', 'Results/Strict/', 'Results/All labs/',
           'Results_perMAA/Main/', 'Results_perMAA/Strict/', 'Results_perMAA/All labs/')
eff_labels <- c('cheating', 'commandments condition', 
                      '10 commandments effect', 'control condition', 'difference')
eff_labels <- rep(list(eff_labels), 6)

plot_params <- data.frame('height'=rep(10, 5),
                          'width' = rep(10, 5),
                          'ilab' = rep('Lab', 5),
                          'summary_only' = rep(FALSE, 5),
                          'auth_width' = c(rep(2.75, 5)),
                          'title ' = c('Matrices Solved (Book prime)',
                                     'Matrices Solved (Commandments prime)',
                                     'Matrices Solved (Cheat)',
                                     'Matrices solved (Control)',
                                     'Difference in effect (Cheat vs. control)'),
                          'g1_lab' = c('Cheat', 'Cheat', 'Commandments', 'Commandments', 'Books'),
                          'g2_lab' = c('Control', 'Control', 'Books', 'Books', 'Commandments'),
                          stringsAsFactors=FALSE)

table_params <- data.frame('class' = c('10 commandments effect', 
                                       'cheating', 
                                       'commandments condition',
                                       'difference',
                                       'control condition'),
                           'g1' = c('Commandments',
                                    'Cheat',
                                    'Cheat',
                                    'Books',
                                    'Commandments'),
                           'g2' = c('Books', 
                                    'Control',
                                    'Control',
                                    'Commandments',
                                    'Books'),
                           'title'= c('Difference in matrices solved between commandments prime and book prime for cheating condition',
                                      'Difference in matrices solved between cheat and control conditions for book prime',
                                      'Difference in matrices solved between cheat and control conditions for commandments prime',
                                      'Difference in effect of cheating between priming conditions',
                                      'Difference in matrices solved between commandments prime and book prime for control condition'),
                           stringsAsFactors=FALSE)

mapply(make_output, analyses, paths, list(original_effects), eff_labels, list(plot_params), 
       list(table_params), meta_regress=TRUE, save_plots=TRUE, table_output=TRUE)

check <- filter(all_dat, label=='self report vs external check')
all_check <- filter(check, !(authors %in% always_exclude))
without_inst <- filter(all_check, authors %in% 
                         c('Aczel', 'Blatz', 'Holzmeister', 'Koppel', 'Laine', 'Loschelder',
                           '\u00D6zdo\u011Fru', 'Suchotzki', 'Tran'))
with_inst <- anti_join(all_check, without_inst)
check_paths <- paste0('Results_perMAA/Check/', c('All/', 'No Inst/', 'Inst/'))
plot_check <- data.frame('height'=10,
                          'width' = 10,
                          'ilab' = 'Lab',
                          'summary_only' = FALSE,
                          'auth_width' = 2.75,
                          'title ' = 'Matrices Solved (Control Condition)',
                          'g1_lab' = 'Self-report',
                          'g2_lab' = 'External check')

table_check <- data.frame('class' = 'self report vs external check',
                           'g1' = 'Self Report',
                           'g2' = 'External Check',
                           'title'= 'Difference in self-reported matrices solved vs. correct matrices for control condition',
                           stringsAsFactors=FALSE)

mapply(make_output, data=list(all_check, without_inst, with_inst), path=check_paths,
       eff_labels='self report vs external check', plot_params = list(plot_check),
       table_params=list(table_check), meta_regress=FALSE, save_plots=TRUE, table_output=TRUE)
